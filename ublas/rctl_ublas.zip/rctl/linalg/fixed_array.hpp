/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once 
#include <boost/numeric/ublas/storage.hpp>

namespace rctl {
    
/** Modified version of ublas::bounded_array<T, N>,
 *  where the "size_" member variable has been removed
 *  to save memory space and possibly improve performance */
template<class T, std::size_t N>
class fixed_array:
    public boost::numeric::ublas::storage_array<fixed_array<T, N> > {

    typedef fixed_array<T, N> self_type;
public:
    typedef /*typename*/ size_t size_type;
    typedef /*typename*/ int difference_type;
    typedef T value_type;
    typedef const T &const_reference;
    typedef T &reference;
    typedef const T *const_pointer;
    typedef T *pointer;
    typedef const_pointer const_iterator;
    typedef pointer iterator;

    // Construction and destruction
    BOOST_UBLAS_INLINE
    fixed_array () {
    }
    explicit BOOST_UBLAS_INLINE
    fixed_array (size_type size) {
        BOOST_UBLAS_CHECK (size == N, ublas::bad_size ());
    }
    BOOST_UBLAS_INLINE
    fixed_array (size_type size, const value_type &init) {
        BOOST_UBLAS_CHECK (size == N, ublas::bad_size ());
        std::fill (begin(), end(), init) ;
    }
    BOOST_UBLAS_INLINE
    fixed_array (const fixed_array<T,N> &c) {
        std::copy (c.data_, c.data_ + N, data_);
    }

    // Resizing
    BOOST_UBLAS_INLINE
    void resize (size_type size) {
        // Fixed size
        BOOST_UBLAS_CHECK (size == N, ublas::bad_size ());
    }
    BOOST_UBLAS_INLINE
    void resize (size_type size, value_type init) {
        // Fixed size
        BOOST_UBLAS_CHECK (size == N, ublas::bad_size ());
    }

    // Random Access Container
    BOOST_UBLAS_INLINE
    size_type max_size () const {
        return N;
    }

    BOOST_UBLAS_INLINE
    bool empty () const {
        return (N == 0);
    }

    BOOST_UBLAS_INLINE
    size_type size () const {
        return N;
    }

    // Element access
    BOOST_UBLAS_INLINE
    const_reference operator [] (size_type i) const {
        BOOST_UBLAS_CHECK (i < N, ublas::bad_index ());
        return data_ [i];
    }
    BOOST_UBLAS_INLINE
    reference operator [] (size_type i) {
        BOOST_UBLAS_CHECK (i < N, ublas::bad_index ());
        return data_ [i];
    }

    // Assignment
    BOOST_UBLAS_INLINE
    fixed_array &operator = (const fixed_array<T,N> &a) {
        if (this != &a) {
            std::copy (a.data_, a.data_ + N, data_);
        }
        return *this;
    }
    BOOST_UBLAS_INLINE
    fixed_array &assign_temporary (fixed_array<T,N> &a) {
        *this = a;
        return *this;
    }

    // Swapping
    BOOST_UBLAS_INLINE
    void swap (fixed_array<T,N> &a) {
        if (this != &a) {
            std::swap_ranges (data_, data_ + N, a.data_);
        }
    }
    BOOST_UBLAS_INLINE
    friend void swap (fixed_array<T,N> &a1, fixed_array<T,N> &a2) {
        a1.swap (a2);
    }

    BOOST_UBLAS_INLINE
    const_iterator begin () const {
        return data_;
    }
    BOOST_UBLAS_INLINE
    const_iterator end () const {
        return data_ + N;
    }

    BOOST_UBLAS_INLINE
    iterator begin () {
        return data_;
    }
    BOOST_UBLAS_INLINE
    iterator end () {
        return data_ + N;
    }

    // Reverse iterators
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
    typedef std::reverse_iterator<iterator>       reverse_iterator;

    BOOST_UBLAS_INLINE
    const_reverse_iterator rbegin () const {
        return const_reverse_iterator (end ());
    }
    BOOST_UBLAS_INLINE
    const_reverse_iterator rend () const {
        return const_reverse_iterator (begin ());
    }
    BOOST_UBLAS_INLINE
    reverse_iterator rbegin () {
        return reverse_iterator (end ());
    }
    BOOST_UBLAS_INLINE
    reverse_iterator rend () {
        return reverse_iterator (begin ());
    }

private:
    BOOST_UBLAS_BOUNDED_ARRAY_ALIGN value_type data_ [N];
};

} // namespace rctl
