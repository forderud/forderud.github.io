/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once
#include <boost/numeric/ublas/matrix.hpp>
#include "rctl/linalg/fixed_array.hpp"

using namespace boost::numeric;

namespace rctl {
// datatype for 3x3 matrix with stack allocation
typedef ublas::matrix<float, ublas::column_major, rctl::fixed_array<float, 9> > mat33;

} // namespace rctl
