/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#include "rctl/linalg/sse_prod.hpp"

// Enable SSE intrinsics
#ifdef _WIN32
#  include <intrin.h>
#endif

namespace rctl {

void _sse_prod (const Matrix & A, const Matrix & X, Matrix /*out*/ & Y, bool clear_y/*=true*/) {
    // column-major compile-time check
    BOOST_STATIC_ASSERT((boost::is_same<Matrix::orientation_category, boost::numeric::ublas::column_major_tag>::value)); 

    const int CACHE_SIZE = 120;    // maximum number of rows in X;
    const int Ni = (int) A.size1();
    const int Nj = (int) X.size2();
    const int Nk = (int) X.size1();
    Y.resize(Ni, Nj, false);

    if (Ni == 0 || Nj == 0)
        return;

    if (clear_y)
        Y.clear();

#ifndef _WIN32
    noalias(Y) += prod(A, X);
#else
    // Failsafe in case Y columns are larger than cache.
    if (Ni > CACHE_SIZE) {
        noalias(Y) += prod(A, X);
        return;
    }

    const int _Ni = Ni - Ni%4; // Number of elements suitable for sse.

    // compute each column in output matrix Y
    #pragma omp parallel for
    for (int j = 0; j < Nj; j++) {
        __m128 _acc[CACHE_SIZE/4]; // Accumulator array for storing row of M temporarily
        float   acc[4-1];          // Accumulator array for storing row of M temporarily

        float * y = &Y(0,j);

        // fill cache with current column of Y
        int l = 0; // j = 4*l SSE counter
        for (l = 0; l < Ni/4; l++)
            _acc[l] = _mm_loadu_ps(y + 4*l);
        for (int i = 4*l; i < Ni; i++)
            acc[i-_Ni] = y[i];

        const float * a = &A(0,0);
        const float * x = &X(0,j);

        for (int k = 0; k < Nk; k++, x++) {
            __m128 _x = _mm_load1_ps(x); // load 4 identical copies of "x"

            // computes 4 columns of "X" in parallel
            for (l = 0; l < Ni/4; l++, a += 4) {
                // SSE instructions for the first 4*Nj elements
                __m128 _a  = _mm_loadu_ps(a);            // load 4 succesive elements of "a"
                __m128 _ax = _mm_mul_ps(_a, _x);         // tmp = {A(i,k)*X(k,j) ... A(i+3,k)*X(k,j)}
                _acc[l]    = _mm_add_ps(_ax, _acc[l]);   // Y(i,j) += tmp
            }
            for (int i = 4*l; i < Ni; i++, a++)
                acc[i-_Ni] += (*a) * (*x);  // standard floating-point for the last 0..3
        }

        // Transfer data from cache to Y
        for (l = 0; l < Ni/4; l++)
            _mm_storeu_ps(y + 4*l, _acc[l]); // store 4 elements to Y.
        for (int i = 4*l; i < Ni; i++)
            y[i] = acc[i-_Ni];
    }
#endif
}


void _sse_prod (const Matrix & A, const Matrix & X, const Matrix & B, Matrix /*out*/ & Y) {
    const int Ni = (int) A.size1();
    const int Nj = (int) X.size2();
    Y.resize(Ni, Nj, false);

    // initialize Y = B
    noalias(Y) = B;

    // Y += A*X
    _sse_prod(A, X, Y, false);
}


void _sse_prod (const Matrix & A, const Vector & X, Vector /*out*/ & Y, bool clear_y/*=true*/) {
    // column-major compile-time check
    BOOST_STATIC_ASSERT((boost::is_same<Matrix::orientation_category, boost::numeric::ublas::column_major_tag>::value)); 

    const int Ni = (int) A.size1();
    const int Nj = (int) A.size2();
    Y.resize(Ni, false);

    if (Ni == 0)
        return;

    // initialize with y = 0
    if (clear_y)
        Y.clear();

#ifndef _WIN32
    noalias(Y) += prod(A, X);
#else
          float * y = &Y(0);
    const float * x = &X(0);

    // compute first 4*N elements of Y
    int l = 0;
    for (l = 0; l < Ni/4; l++) {
        const int     i = 4*l;
        const float * a = &A(i,0);
        __m128       _y = _mm_loadu_ps(y + i);  

        for (int j = 0; j < Nj; j++, a += Ni) {
            // load 4 identical copies of x(j)
            __m128 _x  = _mm_load1_ps(x + j);
            // load A(i,j)..A(i+3,j)  (4 succesive elements)
            __m128 _a  = _mm_loadu_ps(a);
            // elementwise product
            __m128 _ax = _mm_mul_ps(_a, _x); // tmp = {A(i,j)*X(j)...A(i+3,j)*X(j)}
            // elementwise addition
            _y         = _mm_add_ps(_ax,_y); // Y(i,j) += tmp
        }
        _mm_storeu_ps(y + i, _y);
    }
    // compute last 0..3 elements of Y
    for (int i = 4*l; i < Ni; i++) {
        const float * a = &A(i,0);
        for (int j = 0; j < Nj; j++, a += Ni)
            y[i] += (*a) * x[j];
    }
#endif
}


void _sse_prod (const Matrix & A, const Vector & X, const Vector & B, Vector /*out*/ & Y) {
    const int Ni = (int) A.size1();
    Y.resize(Ni, false);

    // initialize with y = b
    noalias(Y) = B;

    // y += A*x
    _sse_prod (A, X, Y, false);
}


void _fast_outer_prod (Matrix & M, const float scale, const Vector & X) {
    // row/column major doesn't matter, since (x*x') is symmetric
    const int N = (int) X.size();
    M.resize(N,N, false);

    const float * x = &X(0);
          float * m = &M(0,0);

    // does not use SSE nor OpenMP, since neither appeares
    // to yield any performance improvement
    for (int j = 0; j < N; j++) {
        const float scale_xj = scale * x[j];
        for (int i = 0; i < N; i++) {
            (*m) += scale_xj * x[i];
            m++;
        }
    }
}

} // namespace rctl
