/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once
#include <cmath>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>
#pragma warning(push)
#pragma warning(disable: 4100) // unreferenced formal parameter
#include "rctl/linalg/fixed_array.hpp"
#pragma warning(pop) // re-enable warning 4100

using namespace boost::numeric;

namespace rctl {

class vec3;
static inline float length (const vec3 & v);

/** Floating-point vector of length 3 to represent spatial coordinates.
 *  Created by inheritance instead of typedef to support convenient contructor. */
class vec3: public ublas::vector<float, rctl::fixed_array<float, 3> > {
    typedef ublas::vector<float, rctl::fixed_array<float, 3> > vector_type;
public:
    typedef vector_type::size_type size_type;
    static const size_type max_size = 3;

    // Construction and destruction
    inline vec3 ():
        vector_type (3) {}
    inline vec3 (size_type size):
        vector_type (size) {}
    inline vec3 (float a, float b, float c): // custom convenient constructor
        vector_type (3) {
		data()[0] = a;
        data()[1] = b;
        data()[2] = c;
	}
    inline vec3 (const vec3 &v):
        vector_type (v) {}
    template<class A2>              // Allow vector<float,bounded_array<3> construction
    inline vec3 (const ublas::vector<float, A2> &v):
        vector_type (v) {}
    template<class AE>
    inline vec3 (const ublas::vector_expression<AE> &ae):
        vector_type (ae) {}
    inline ~vec3 () {}

    // Assignment
    inline vec3 &operator = (const vec3 &v) {
        data()[0] = v.data()[0];
        data()[1] = v.data()[1];
        data()[2] = v.data()[2];
        return *this;
    }
    template<class A2>         // Generic vector assignment
    inline vec3 &operator = (const ublas::vector<float, A2> &v) {
        vector_type::operator = (v);
        return *this;
    }
    template<class C>          // Container assignment without temporary
    inline vec3 &operator = (const ublas::vector_container<C> &v) {
        vector_type::operator = (v);
        return *this;
    }
    template<class AE>
    inline vec3 &operator = (const ublas::vector_expression<AE> &ae) {
        vector_type::operator = (ae);
        return *this;
    }

	/// Normalize vector
	inline void normalize () {
		float len = length(*this);
		data()[0] /= len;
		data()[1] /= len;
		data()[2] /= len;
	}

    /// Equality operators
    inline bool operator == (const vec3 &v) {
        if ( data()[0] == v.data()[0] &&
             data()[1] == v.data()[1] &&
             data()[2] == v.data()[2] )
            return true;

        return false;
    }
    inline bool operator != (const vec3 &v) {
        return !(*this == v);
    }
};

// 16-byte aligned variant of vec3, for SSE usage
#ifdef _WIN32
typedef __declspec(align(16)) vec3 vec3a;
#endif

static const vec3 VEC3_ZERO(0.0f, 0.0f, 0.0f);

static inline float sq_length (const vec3 & v) {
	float x = v(0);
	float y = v(1);
	float z = v(2);

	return x*x + y*y + z*z;
}

static inline float length (const vec3 & v) {
	return sqrt(sq_length(v));
}

/** Calculates the vector cross-product */
static inline vec3 cross_product (const vec3 & a, const vec3 & b) {
    float ax = a(0);
    float ay = a(1);
    float az = a(2);

    float bx = b(0);
    float by = b(1);
    float bz = b(2);

    return vec3(ay*bz - az*by, az*bx - ax*bz, ax*by - ay*bx);
}

} //namespace
