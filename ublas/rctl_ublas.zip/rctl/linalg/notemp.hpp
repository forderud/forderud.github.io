#pragma once
#include <boost/numeric/ublas/detail/definitions.hpp>
#include "rctl/linalg/sse_prod.hpp"


namespace rctl {

template<class E1, class E2>
class sse_prod2 : public boost::noncopyable {
public:
	sse_prod2 (const E1 & _e1,
		       const E2 & _e2) : e1(_e1), e2(_e2) {
	}
	const E1 & e1;
	const E2 & e2;
};
template<class E1, class E2>
class sse_prod3 : public boost::noncopyable {
public:
	sse_prod3 (const E1 & _e1,
		       const E2 & _e2,
		       const E2 & _e3) : e1(_e1), e2(_e2), e3(_e3) {
	}
	const E1 & e1;
	const E2 & e2;
	const E2 & e3;
};
class fast_outer_prod2 : public boost::noncopyable {
public:
	fast_outer_prod2 (const float        & _e1,
		              const rctl::Vector & _e2) : e1(_e1), e2(_e2) {
	}
	const float          e1;
	const rctl::Vector & e2;
};

/** Alternative version of ublas::noalias() that:
  - Resizes the destination container on assignment.
  - Is extended with SIMD support.                */
template<class C>
class notemp_proxy:
    private ublas::nonassignable {
public:
    typedef typename C::closure_type closure_type;

    BOOST_UBLAS_INLINE
    notemp_proxy (C& lval):
        nonassignable (), lval_ (lval) {}
    BOOST_UBLAS_INLINE
    notemp_proxy (const notemp_proxy& p):
        nonassignable (), lval_ (p.lval_) {}

    template <class E>
    BOOST_UBLAS_INLINE
	closure_type &operator = (const ublas::matrix_expression<E> & e) {
		// auto resize LHS
		lval_.expression().resize(e().size1(),e().size2(), false);
        lval_.assign (e);
        return lval_;
    }
    template <class E>
    BOOST_UBLAS_INLINE
    closure_type &operator = (const ublas::vector_expression<E> & e) {
		// auto resize LHS
		lval_.expression().resize(e().size(), false);
        lval_.assign (e);
        return lval_;
    }

	/** SIMD implementation of: LHS = prod(A, x). */
    BOOST_UBLAS_INLINE
	closure_type &operator = (const sse_prod2<rctl::Matrix,rctl::Vector> & e) {
		// resize handled by _sse_prod
		rctl::_sse_prod(e.e1, e.e2, lval_.expression());
        return lval_;
    }
	/** SIMD implementation of: LHS = prod(A, X). */
    BOOST_UBLAS_INLINE
    closure_type &operator = (const sse_prod2<rctl::Matrix,rctl::Matrix> & e) {
		// resize handled by _sse_prod
		rctl::_sse_prod(e.e1, e.e2, lval_.expression());
        return lval_;
    }
	/** SIMD implementation of: LHS = prod(A, x) + b. */
    BOOST_UBLAS_INLINE
	closure_type &operator = (const sse_prod3<rctl::Matrix,rctl::Vector> & e) {
		// resize handled by _sse_prod
		rctl::_sse_prod(e.e1, e.e2, e.e3, lval_.expression());
        return lval_;
    }
	/** SIMD implementation of: LHS = prod(A, X) + B. */
    BOOST_UBLAS_INLINE
    closure_type &operator = (const sse_prod3<rctl::Matrix,rctl::Matrix> & e) {
		// resize handled by _sse_prod
		rctl::_sse_prod(e.e1, e.e2, e.e3, lval_.expression());
        return lval_;
    }
	/** Efficient implementation of: LHS += s * outer_prod(x,x). */
    BOOST_UBLAS_INLINE
    closure_type &operator += (const fast_outer_prod2 & e) {
		// resize should not be required
		rctl::_fast_outer_prod(lval_.expression(), e.e1, e.e2);
        return lval_;
    }

    template <class E>
    BOOST_UBLAS_INLINE
    closure_type &operator += (const E& e) {
		// resize should not be required
        lval_.plus_assign (e);
        return lval_;
    }
    template <class E>
    BOOST_UBLAS_INLINE
    closure_type &operator -= (const E& e) {
		// resize should not be required
        lval_.minus_assign (e);
        return lval_;
    }

private:
    closure_type lval_;
};

/** Effcient assignment with LHS resize where no aliases of LHS appear on RHS.
 *   nocopy(lhs) = expression */
template <class C>
BOOST_UBLAS_INLINE
notemp_proxy<C> notemp (C& lvalue) {
    return notemp_proxy<C> (lvalue);
}
/** Effcient assignment with LHS resize where no aliases of LHS appear on RHS.
 *   nocopy(lhs) = expression */
template <class C>
BOOST_UBLAS_INLINE
notemp_proxy<const C> notemp (const C& lvalue) {
    return notemp_proxy<const C> (lvalue);
}

/** SIMD implementation of: LHS = A * x. */
template<class E1, class E2> inline
sse_prod2<E1,E2> sse_prod (const E1 & A, const E2 & X) {
	return sse_prod2<E1,E2>(A, X);
}
/** SIMD implementation of: LHS = A * x + b. */
template<class E1, class E2> inline
sse_prod3<E1,E2> sse_prod (const E1 & A, const E2 & X, const E2 & B) {
	return sse_prod3<E1,E2>(A, X, B);
}
/** Efficient implementation of: LHS += factor * outer_prod(x,x). */
inline
fast_outer_prod2 fast_outer_prod (const float & factor, const rctl::Vector & x) {
	return fast_outer_prod2(factor, x);
}

} // namespace rctl
