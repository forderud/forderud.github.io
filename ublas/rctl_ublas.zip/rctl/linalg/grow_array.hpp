/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once 
#include <boost/numeric/ublas/storage.hpp>

namespace rctl {
#pragma warning(push)
#pragma warning(disable: 4127) // conditional expression is constant

/** Modified version of ublas::unbounded_array<T,ALLOC>,
 *  with non-decreasing capacity to improve resize performance */
template<class T, class ALLOC = std::allocator<T> >
class grow_array :
    public boost::numeric::ublas::storage_array<grow_array<T, ALLOC> > {

    typedef grow_array<T, ALLOC> self_type;
public:
    typedef ALLOC allocator_type;
    typedef typename ALLOC::size_type size_type;
    typedef typename ALLOC::difference_type difference_type;
    typedef T value_type;
    typedef const T &const_reference;
    typedef T &reference;
    typedef const T *const_pointer;
    typedef T *pointer;
    typedef const_pointer const_iterator;
    typedef pointer iterator;

    // Construction and destruction
    explicit BOOST_UBLAS_INLINE
    grow_array (const ALLOC &a = ALLOC()):
        alloc_ (a), size_ (0), capacity_ (0) {
        data_ = 0;
    }
    explicit BOOST_UBLAS_INLINE
    grow_array (size_type size, const ALLOC &a = ALLOC()):
        alloc_(a), size_ (size), capacity_ (size) {
        using namespace boost::numeric;
        if (size_) {
            data_ = alloc_.allocate (capacity_);
            if (! ublas::detail::has_trivial_constructor<T>::value) {
                for (pointer d = data_; d != data_ + size_; ++d)
                    alloc_.construct(d, value_type());
            }
        }
        else
            data_ = 0;
    }
    // No value initialised, but still be default constructed
    BOOST_UBLAS_INLINE
    grow_array (size_type size, const value_type &init, const ALLOC &a = ALLOC()):
        alloc_ (a), size_ (size), capacity_ (size) {
        if (size_) {
            data_ = alloc_.allocate (capacity_);
            std::uninitialized_fill (begin(), end(), init);
        }
        else
            data_ = 0;
    }
    BOOST_UBLAS_INLINE
    grow_array (const grow_array &c):
        storage_array<grow_array<T, ALLOC> >(),
        alloc_ (c.alloc_), size_ (c.size_), capacity_ (c.size_) {
        if (size_) {
            data_ = alloc_.allocate (capacity_);
            std::uninitialized_copy (c.begin(), c.end(), begin());
        }
        else
            data_ = 0;
    }
    BOOST_UBLAS_INLINE
    ~grow_array () {
        using namespace boost::numeric;
        // destruct
        if (size_ && !ublas::detail::has_trivial_destructor<T>::value) {
            // std::_Destroy (begin(), end(), alloc_);
            const iterator i_end = end();
            for (iterator i = begin (); i != i_end; ++i) {
                iterator_destroy (i); 
            }
        }
        // deallocate
        if (data_ && capacity_)
            alloc_.deallocate (data_, capacity_);
    }

    // Resizing
private:
    BOOST_UBLAS_INLINE
    void resize_shrinkgrow (const size_type new_size, const value_type init) {
        using namespace boost::numeric;
        // WARNING: Does not perform any capacity_ checking!

        if (new_size > size_) {
            // construct more elements to grow size
            if (! ublas::detail::has_trivial_constructor<T>::value)
                for (pointer di = data_+size_; di != data_+new_size; ++di)
                    alloc_.construct(di, init);
        } else { // new_size <= size_
            // destruct some elements to shink size
            if (! ublas::detail::has_trivial_destructor<T>::value)
                for (pointer si = data_+new_size; si != data_+size_; ++si)
                    alloc_.destroy(si);
        }
        size_ = new_size;
    }


    BOOST_UBLAS_INLINE
    void resize_internal (const size_type new_size, const value_type init, const bool preserve) {
        using namespace boost::numeric;
        if (new_size == size_)
            return;

        if (new_size <= capacity_) {
            // re-use current array
            return resize_shrinkgrow(new_size, init);
        }

        // allocate new & larger array
        pointer old_data = data_;
        size_t  old_cap  = capacity_;
        data_     = alloc_.allocate (new_size);
        capacity_ = new_size;

        if (preserve) {
            pointer di = data_;
            // copy content
            for (pointer si = old_data; si != old_data + size_; ++si) {
                alloc_.construct (di, *si);
                ++di;
            }
            // pad with default values
            for (; di != data_+new_size; ++di) {
                alloc_.construct (di, init);
            }
        } else {
            // don't copy content
            if (! ublas::detail::has_trivial_constructor<T>::value) {
                for (pointer di = data_; di != data_+new_size; ++di)
                    alloc_.construct (di, value_type());
            }
        }

        if (size_) {
            // destroy & deallocate old array
            if (! ublas::detail::has_trivial_destructor<T>::value) {
                for (pointer si = old_data; si != old_data+size_; ++si)
                    alloc_.destroy (si);
            }
            alloc_.deallocate (old_data, old_cap);
        }

        // update with new size
        size_ = new_size;
    }
public:
    BOOST_UBLAS_INLINE
    void resize (size_type size) {
        resize_internal (size, value_type (), false);
    }
    BOOST_UBLAS_INLINE
    void resize (size_type size, value_type init) {
        resize_internal (size, init, true);
    }
                
    // Random Access Container
    BOOST_UBLAS_INLINE
    size_type max_size () const {
        return ALLOC ().max_size();
    }
    
    BOOST_UBLAS_INLINE
    bool empty () const {
        return size_ == 0;
    }
        
    BOOST_UBLAS_INLINE
    size_type size () const {
        return size_;
    }

    // Element access
    BOOST_UBLAS_INLINE
    const_reference operator [] (size_type i) const {
        BOOST_UBLAS_CHECK (i < size_, ublas::bad_index ());
        return data_ [i];
    }
    BOOST_UBLAS_INLINE
    reference operator [] (size_type i) {
        BOOST_UBLAS_CHECK (i < size_, ublas::bad_index ());
        return data_ [i];
    }

    // Assignment
    BOOST_UBLAS_INLINE
    grow_array &operator = (const grow_array &a) {
        if (this != &a) {
            resize (a.size_);
            std::copy (a.data_, a.data_ + a.size_, data_);
        }
        return *this;
    }
    BOOST_UBLAS_INLINE
    grow_array &assign_temporary (grow_array &a) {
        swap (a);
        return *this;
    }

    // Swapping
    BOOST_UBLAS_INLINE
    void swap (grow_array &a) {
        if (this != &a) {
            std::swap (size_,     a.size_);
            std::swap (capacity_, a.capacity_);
            std::swap (data_,     a.data_);
        }
    }
    BOOST_UBLAS_INLINE
    friend void swap (grow_array &a1, grow_array &a2) {
        a1.swap (a2);
    }

    BOOST_UBLAS_INLINE
    const_iterator begin () const {
        return data_;
    }
    BOOST_UBLAS_INLINE
    const_iterator end () const {
        return data_ + size_;
    }

    BOOST_UBLAS_INLINE
    iterator begin () {
        return data_;
    }
    BOOST_UBLAS_INLINE
    iterator end () {
        return data_ + size_;
    }

    // Reverse iterators
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
    typedef std::reverse_iterator<iterator> reverse_iterator;

    BOOST_UBLAS_INLINE
    const_reverse_iterator rbegin () const {
        return const_reverse_iterator (end ());
    }
    BOOST_UBLAS_INLINE
    const_reverse_iterator rend () const {
        return const_reverse_iterator (begin ());
    }
    BOOST_UBLAS_INLINE
    reverse_iterator rbegin () {
        return reverse_iterator (end ());
    }
    BOOST_UBLAS_INLINE
    reverse_iterator rend () {
        return reverse_iterator (begin ());
    }

    // Allocator
    allocator_type get_allocator () {
        return alloc_;
    }

private:
    // Handle explict destroy on a (possibly indexed) iterator
    BOOST_UBLAS_INLINE
    static void iterator_destroy (iterator &i) {
        (&(*i)) -> ~value_type ();
    }
    ALLOC alloc_;
    size_type size_;
    size_type capacity_;  /// array capacity (<= size)
    pointer data_;
};
#pragma warning(pop) // re-enable warning 4127

} // namrspace rctl
