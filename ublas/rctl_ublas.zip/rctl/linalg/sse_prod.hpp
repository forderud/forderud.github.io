/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include "rctl/linalg/grow_array.hpp"


namespace rctl {
using namespace boost::numeric;

#ifndef RCTL_FLOAT
typedef float                             FLOAT;
#define RCTL_FLOAT
#endif
#ifndef RCTL_VECTOR
typedef ublas::vector<FLOAT,
               rctl::grow_array<FLOAT> >  Vector;
#define RCTL_VECTOR
#endif
#ifndef RCTL_MATRIX
typedef ublas::matrix<FLOAT,
               ublas::column_major,
               rctl::grow_array<FLOAT> >  Matrix;
#define RCTL_MATRIX
#endif

/** Computes matrix-matrix product. Y += A*X.
 *  Optimized with SSE/SIMD vectorization and OpenMP parallelization.
 *  WARNING: Assumes thightly packed column-major matrices. */
void _sse_prod (const Matrix & A, const Matrix & X, Matrix /*out*/ & Y, bool clear_y=true);


/** Computes matrix-matrix product Y = A*X + B.
 *  Optimized with SSE/SIMD vectorization and OpenMP parallelization. */
void _sse_prod (const Matrix & A, const Matrix & X, const Matrix & B, Matrix /*out*/ & Y);


/** Computes matrix-vector product y += A*x
 *  WARNING: Assumes thightly packed column-major matrices. */
void _sse_prod (const Matrix & A, const Vector & X, Vector /*out*/ & Y, bool clear_y=true);


/** SSE SIMD implementation of matrix-vector product y = A*x + b */
void _sse_prod (const Matrix & A, const Vector & X, const Vector & B, Vector /*out*/ & Y);


/** Computes scaled outer product of vector "x" and adds it to matrix "M".
 *  M += scale * x * x'             */
void _fast_outer_prod (Matrix & M, const float scale, const Vector & X);

} // namespace rctl
