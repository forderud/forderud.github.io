#include "rctl/linalg/vec3.hpp"
#include "rctl/linalg/quat.hpp"
#include "rctl/linalg/notemp.hpp"
#include "rctl/linalg/sse_prod.hpp"
using namespace boost::numeric;
using namespace rctl;

/** Create vector and fill it with "random" data. */
static Vector init_vector (const size_t dim) {
    Vector X(dim);
    for (size_t i = 0; i < dim; i++)
        X(i) = 0.21345f * i + 23.7f;
    return X;
}

/** Create matrix and fill it with "random" data. */
static Matrix init_matrix (const size_t dim1, const size_t dim2) {
    Matrix A(dim1,dim2);
    for (size_t i = 0; i < dim1; i++)
        for (size_t j = 0; j < dim2; j++)
            A(i,j) = 3.1f*i + 6.01f*j - 346.3f;
    return A;
}

/** Example code to demonstrate usage of the RCTL Boost UBLAS extensions. */
void linalg_examples () {
    // stack-bases vector of size 3
    vec3 point(0.5f, 0.2f, -0.6f);
    // normalize to unit length
    point.normalize();

    // create quaternion based on euler angles
    quat rot = quat::from_euler(quat::RXYZ, vec3(0, 3.14f/2, 0));
    // rotate point
    vec3 rotated = prod(rot, point);

    // initialize datastructures
    const size_t N = 10;
    Vector X = init_vector(N);
    Vector Y = init_vector(N);
    Vector Z(N); Z.clear();
    Matrix A = init_matrix(N,N);
    Matrix B = init_matrix(N,N);
    Matrix C = init_matrix(N,N);
    Matrix D(N,N); D.clear();

    // SSE/OpenMP matrix-vector product Z = A*X
    notemp(Y) = sse_prod(A, X);

    // SSE/OpenMP matrix-vector product Z = A*X + Y
    notemp(Y) = sse_prod(A, X, Y); // not 100% optimal syntax

    // SSE/OpenMP matrix-matrix product C = A*B
    notemp(C) = sse_prod(A, B);

    // SSE/OpenMP matrix-matrix product C = A*B + C
    notemp(C) = sse_prod(A, B, C); // not 100% optimal syntax
}
