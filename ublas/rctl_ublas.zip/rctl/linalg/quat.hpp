/*         Real-time Contour Tracking Library (RCTL)         *
 *          primarily developed by Fredrik Orderud           */
#pragma once
#include "rctl/linalg/mat33.hpp"
#include "rctl/linalg/vec3.hpp"

using namespace boost::numeric;

namespace rctl {
/** Quaternion class, for representing spatial rotations [w, x, y, z],
 *  where w = cos(angle/2) & [x,y,z] = axis * sin(angle/2). */
class quat {
public:
    /// data container
    typedef rctl::fixed_array<float, 4> array_type;

    quat () : data_(4, 0) {
    }
    quat (const float _w, const float _x, const float _y, const float _z) {
        w() = _w;
        x() = _x;
        y() = _y;
        z() = _z;
    }
    quat (const quat & other) : data_(other.data_) {
    }
    quat (const vec3 & axis, const float angle) {
        w() =         cos(angle/2);
        x() = axis(0)*sin(angle/2);
        y() = axis(1)*sin(angle/2);
        z() = axis(2)*sin(angle/2);
    }
    quat & operator = (const quat & other) {
        if (this != &other) {
            data_ = array_type(other.data_);
        }
        return *this;
    }

    /** Quaternion multiplication. */
    quat operator * (const quat & o) const {
        float _w = w()*o.w() - x()*o.x() - y()*o.y() - z()*o.z();
        float _x = w()*o.x() + x()*o.w() + y()*o.z() - z()*o.y();
        float _y = w()*o.y() + y()*o.w() + z()*o.x() - x()*o.z();
        float _z = w()*o.z() + z()*o.w() + x()*o.y() - y()*o.x();
        return quat(_w,_x,_y,_z);
    }

    /** Quaternion length/norm. Should be close to 1. */
    float length () const {
        float sq_len = w()*w() + x()*x()
                     + y()*y() + z()*z();
        return sqrt(sq_len);
    }
    /** Normalize quaternion into unit norm. */
    void normalize () {
        float len = length();
        w() /= len;
        x() /= len;
        y() /= len;
        z() /= len;
    }

    /** Compute quaternion rotation matrix. */
    mat33 rot_mat () const {
        const float W = w(), X = x(), Y = y(), Z = z();
        mat33 mat(3,3);
        mat(0,0) = W*W+X*X-Y*Y-Z*Z; mat(0,1) = 2*X*Y-2*W*Z;     mat(0,2) = 2*W*Y+2*X*Z;
        mat(1,0) = 2*W*Z+2*X*Y;     mat(1,1) = W*W-X*X+Y*Y-Z*Z; mat(1,2) = 2*Y*Z-2*W*X;
        mat(2,0) = 2*X*Z-2*W*Y;     mat(2,1) = 2*W*X+2*Y*Z;     mat(2,2) = W*W-X*X-Y*Y+Z*Z;
        return mat;
    }

    /** Order of rotation around the axes.
     *  RXYZ = RX * RY * RZ (RZ applied first, then RY, followed by RX). */
    enum ROT_TYPE {RXYZ, RXZY, RYXZ, RYZX, RZXY, RZYX};

    /* Conversion of  Euler angles (rx,ry,rz) [radians] into a quaternion. */
    static quat from_euler (const ROT_TYPE type, const vec3 & rot_xyz) {
        quat qx(vec3(1,0,0), rot_xyz(0)); // rot x
        quat qy(vec3(0,1,0), rot_xyz(1)); // rot y
        quat qz(vec3(0,0,1), rot_xyz(2)); // rot z

        if      (type == RXYZ)
            return qx * qy * qz;
        else if (type == RXZY)
            return qx * qz * qy;
        else if (type == RYXZ)
            return qy * qx * qz;
        else if (type == RYZX)
            return qy * qz * qx;
        else if (type == RZXY)
            return qz * qx * qy;
        else if (type == RZYX)
            return qz * qy * qx;
        else
            throw std::runtime_error("rctl::quat::from_euler invalid type");
    }

    /** Convert a quaternion into euler angles (rx,ry,rz) [radians]. */
    static vec3 to_euler (const ROT_TYPE type, const quat & q) {
        // compute rotation matrix
        mat33 mat = q.rot_mat();
        // TODO: add bounds checking for gimbal lock
        vec3 rot_xyz(0,0,0);
        if        (type == RXYZ) {
            rot_xyz(0) = atan2( mat(1,2), mat(2,2));
            rot_xyz(1) = asin (-mat(0,2)          );
            rot_xyz(2) = atan2( mat(0,1), mat(0,0));
        } else if (type == RXZY) {
            rot_xyz(0) = atan2(-mat(2,1), mat(1,1));
            rot_xyz(1) = atan2(-mat(0,2), mat(0,0));
            rot_xyz(2) = asin ( mat(0,1)          );
        } else if (type == RYXZ) {
            rot_xyz(0) = asin ( mat(1,2)          );
            rot_xyz(1) = atan2(-mat(0,2), mat(2,2));
            rot_xyz(2) = atan2(-mat(1,0), mat(1,1));
        } else if (type == RYZX) {
            rot_xyz(0) = atan2( mat(1,2), mat(1,1));
            rot_xyz(1) = atan2( mat(2,0), mat(0,0));
            rot_xyz(2) = asin (-mat(1,0)          );
        } else if (type == RZXY) {
            rot_xyz(0) = asin (-mat(2,1)          );
            rot_xyz(1) = atan2( mat(2,0), mat(2,2));
            rot_xyz(2) = atan2( mat(0,1), mat(1,1));
        } else if (type == RZYX) {
            rot_xyz(0) = atan2(-mat(2,1), mat(2,2));
            rot_xyz(1) = asin ( mat(2,0)          );
            rot_xyz(2) = atan2(-mat(1,0), mat(0,0));
        } else
            throw std::runtime_error("rctl::quat::to_euler invalid type.");
        return -rot_xyz;
    }

    BOOST_UBLAS_INLINE
    array_type & data () {
        return data_;
    }
private:
    const float   w () const {return data_[0];}
          float & w ()       {return data_[0];}
    const float   x () const {return data_[1];}
          float & x ()       {return data_[1];}
    const float   y () const {return data_[2];}
          float & y ()       {return data_[2];}
    const float   z () const {return data_[3];}
          float & z ()       {return data_[3];}
    
    array_type data_;
};

/** Rotate spatial point p using quaternion q. */
static vec3 prod (const quat & q, const vec3 & p) {
    mat33 mat = q.rot_mat();
    return ublas::prod(mat, p);
}

} // namespace rctl
