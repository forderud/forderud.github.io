#include "StdAfx.h"     // Standard framework file used for precompiled headers

#include "ifmgr.h"      // Header for the IM DLL app.
#include "impl.h"       // Header for this module.


InterfaceManager::InterfaceManager()
{

}

InterfaceManager::~InterfaceManager() {
}



STDMETHODIMP InterfaceManager::SetParam(int paramId, const ScVariant& objectId, int packageId, const ScVariant& data)
{
    return E_FAIL;
}

STDMETHODIMP InterfaceManager::GetParam(int paramId, const ScVariant& objectId, int packageId, ScVariant *  const data)
{
    return E_FAIL;
}

STDMETHODIMP InterfaceManager::HandleEvent(int eventId, const ScVariant& objectId, int packageId, const ScVariant& data)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::PreInitialize(int /*packageId*/, IManager* managerIf, IPackage* packageIf)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::PostInitialize()
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::Terminate()
{
    return S_OK;
}


STDMETHODIMP InterfaceManager::Startup(IPackage* /*loaderIf*/, IUnknown* mgrctrlIf, const wchar_t* /*logfilename*/)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::Shutdown()
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::CreatePackage(const wchar_t* nameOrClsid, const wchar_t* packageName)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::AddPackage(IUnknown* packageIf, const wchar_t* packageName)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::RegParam(int packageId, int localId, const wchar_t* paramName, BOOL supply, int * paramId)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::RegEvent(int packageId, int localId, const wchar_t* eventName, BOOL subscribe, int * eventId)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::Subscribe(int packageId, int localId, int eventId)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::Unsubscribe(int packageId, int eventId)
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::UnsubscribeAll(int packageId)
{

    return S_OK;
}

STDMETHODIMP InterfaceManager::HandleError(int packageId, const wchar_t* message, const wchar_t* severity)
{
    return S_OK;
}



STDMETHODIMP InterfaceManager::SetParam(int packageId, const wchar_t* paramName, const ScVariant& objectId, const ScVariant& data) 
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::GetParam(int packageId, const wchar_t* paramName, const ScVariant& objectId, ScVariant*  const data) 
{
    return S_OK;
}

STDMETHODIMP InterfaceManager::HandleEvent(int packageId, const wchar_t* eventName, const ScVariant& objectId, const ScVariant& data) 
{
    return S_OK;
}
