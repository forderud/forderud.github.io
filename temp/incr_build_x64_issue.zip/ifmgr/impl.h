#if !defined(AFX_IMPL_H__89E3A225_9D10_11D2_9A79_A56E761E7875__INCLUDED_)
#define AFX_IMPL_H__89E3A225_9D10_11D2_9A79_A56E761E7875__INCLUDED_

#pragma once

#include "ifmgr.h"
class ScVariant;
#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// InterfaceManager

class InterfaceManager :
    public CComDualImpl<IManager, &IID_IManager, &LIBID_IFMGRLib>, 
    public CComDualImpl<IManager2, &IID_IManager2, &LIBID_IFMGRLib>, 
    //public CComDualImpl<IPackage2, &IID_IPackage2, &LIBID_IFMGRLib>, 
    public CComDualImpl<IManagerControl, &IID_IManagerControl, &LIBID_IFMGRLib>, 
    public CComObjectRoot,
    public CComCoClass<InterfaceManager,&CLSID_InterfaceManager>
{
public:
    // Construction / Destruction
    InterfaceManager();
    virtual ~InterfaceManager();

BEGIN_COM_MAP(InterfaceManager)
    COM_INTERFACE_ENTRY(IManager)
    COM_INTERFACE_ENTRY(IManager2)
    COM_INTERFACE_ENTRY(IManagerControl)
END_COM_MAP()

DECLARE_REGISTRY_RESOURCEID(IDR_InterfaceManager)

public:
    STDMETHOD(SetParam)(int paramId, const ScVariant& objectId, int packageId, const ScVariant& data);
    STDMETHOD(GetParam)(int paramId, const ScVariant& objectId, int packageId, ScVariant*  const data);
    STDMETHOD(HandleEvent)(int eventId, const ScVariant& objectId, int packageId, const ScVariant& data);
    STDMETHOD(PreInitialize)(int packageId, IManager* managerIf, IPackage* packageIf);
    STDMETHOD(PostInitialize)();
    STDMETHOD(Terminate)();

    STDMETHOD(CreatePackage)(const wchar_t* nameOrClsid, const wchar_t* packageName);
    STDMETHOD(AddPackage)(IUnknown* packageIf, const wchar_t* packageName);
    STDMETHOD(RegParam)(int packageId, int localId, const wchar_t* paramName, BOOL supply, int* paramId);
    STDMETHOD(RegEvent)(int packageId, int localId, const wchar_t* eventName, BOOL subscribe, int* eventId);
    STDMETHOD(Subscribe)(int packageId, int localId, int eventId);
    STDMETHOD(Unsubscribe)(int packageId, int eventId);
    STDMETHOD(UnsubscribeAll)(int packageId);
    STDMETHOD(HandleError)(int packageId, const wchar_t* message, const wchar_t* severity);

    STDMETHOD(Startup)(IPackage* loaderIf, IUnknown* mgrctrlIf, const wchar_t* logfilename);
    STDMETHOD(Shutdown)();

    STDMETHOD(SetParam)(int pckId, const wchar_t* paramName, const ScVariant& objectId, const ScVariant& data);
    STDMETHOD(GetParam)(int pckId, const wchar_t* paramName, const ScVariant& objectId, ScVariant*  const data);
    STDMETHOD(HandleEvent)(int pckId, const wchar_t* eventName, const ScVariant& objectId, const ScVariant& data);
};

#endif // !defined(AFX_IMPL_H__89E3A225_9D10_11D2_9A79_A56E761E7875__INCLUDED_)
