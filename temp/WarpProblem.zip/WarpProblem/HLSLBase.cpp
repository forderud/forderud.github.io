#include "HLSLBase.hpp"


HLSLBase::HLSLBase (ID3D10Device & d3ddev, const std::string filename) {
    // load HLSL effect
    DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
#if defined _DEBUG
    dwShaderFlags |= D3D10_SHADER_DEBUG;
#endif
    ID3D10BlobPtr errors;
    D3D10CreateBlob(4096, &errors);
    HRESULT hr = D3DX10CreateEffectFromFileA(filename.c_str(), nullptr, nullptr, "fx_4_0", dwShaderFlags, 0, &d3ddev, nullptr, nullptr, &m_effect, &errors, nullptr);

    if (FAILED(hr)) {
        if (errors) {
            const char* error_ptr = static_cast<const char*>(errors->GetBufferPointer());
            throw std::logic_error(error_ptr);
        } else {
            throw std::logic_error("Failed to load effect file");
        }
    }
    if (!m_effect->IsValid())
        throw std::logic_error("invalid effect file");

    // setup vertex data
    VERT_TYPE vertices[4] = {
        {-1, +1, 0, -0.5f, 0, 0}, //top-left
        {+1, +1, 0, +0.5f, 0, 0}, //top-right
        {-1, -1, 0, -0.5f, 1, 0}, //bottom-left
        {+1, -1, 0, +0.5f, 1, 0}, //bottom-right
    };
    memcpy(m_vertices, vertices, sizeof(vertices));

    // create vertex buffer
    D3D10_BUFFER_DESC bd = {};
    bd.Usage          = D3D10_USAGE_DYNAMIC;
    bd.ByteWidth      = sizeof(vertices);
    bd.BindFlags      = D3D10_BIND_VERTEX_BUFFER;
    bd.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    bd.MiscFlags      = 0;
    D3D10_SUBRESOURCE_DATA InitData = {};
    InitData.pSysMem = vertices;
    D3DV(d3ddev.CreateBuffer(&bd, &InitData, &m_vertexBuffer));
        
    // create rasterizer state
    D3D10_RASTERIZER_DESC rasterizerState = {};
    rasterizerState.FillMode = D3D10_FILL_SOLID;
    rasterizerState.CullMode = D3D10_CULL_NONE;
    d3ddev.CreateRasterizerState(&rasterizerState, &m_rState);
}

HLSLBase::~HLSLBase () {
    // auto-cleanup
}

void HLSLBase::Render (ID3D10Device & d3ddev, const std::string & techique_name, unsigned int width, unsigned int height) {
    // obtain the technique
    ID3D10EffectTechnique * technique = m_effect->GetTechniqueByName(techique_name.c_str()); // weak ptr.
    if (!technique->IsValid())
        throw std::logic_error("invalid technique " + techique_name);

    {
        // configure viewport to match render-target resolution
        D3D10_VIEWPORT viewport = {};
        viewport.Width    = width;
        viewport.Height   = height;
        viewport.MinDepth = 0.0f;
        viewport.MaxDepth = 1.0f;
        viewport.TopLeftX = 0;
        viewport.TopLeftY = 0;
        d3ddev.RSSetViewports(1, &viewport);

        // define input layout
        D3D10_INPUT_ELEMENT_DESC layout [] = {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0,                 D3D10_INPUT_PER_VERTEX_DATA, 0 }, // x,y,z   (3*4Byte)
            { "TEXTURE",  0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12 /*byte offset*/, D3D10_INPUT_PER_VERTEX_DATA, 0 }, // u,v,w   (3*4Byte)
        };

        // create input layout
        ID3D10EffectPass * pass = technique->GetPassByIndex(0); // weak ptr
        if (!pass->IsValid())
            throw std::logic_error("technique pass invalid");
        D3D10_PASS_DESC PassDesc = {};
        D3DV(pass->GetDesc(&PassDesc));
        D3DV(d3ddev.CreateInputLayout(layout, ARRAYSIZE(layout), PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_vertexLayout));

        // assign input layout
        d3ddev.IASetInputLayout(m_vertexLayout);

        // set vertex buffer
        UINT stride = sizeof(VERT_TYPE);
        UINT offset = 0;
        ID3D10Buffer * buffers[] = {m_vertexBuffer.GetInterfacePtr()};
        d3ddev.IASetVertexBuffers(0, 1, buffers, &stride, &offset);

        // set quadrilateral/vertex topology
        d3ddev.IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

        d3ddev.RSSetState(m_rState);
    }

    {
        // perform rendering
        D3D10_TECHNIQUE_DESC techDesc = {};   
        technique->GetDesc(&techDesc);
        for(unsigned int p = 0; p < techDesc.Passes; p++) {
            D3DV(technique->GetPassByIndex(p)->Apply(0));
            d3ddev.Draw(4, 0);
        }
    }
}
