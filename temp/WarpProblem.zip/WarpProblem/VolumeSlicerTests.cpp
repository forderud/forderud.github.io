#include <memory>  // shared_ptr
#include <iostream>

#include "Direct3d.hpp"
#include "VolumeSlicer.hpp"
#include "TextureAccess.hpp"

#include "TestCommon.hpp"


static unsigned int createDeviceFlags = D3D10_CREATE_DEVICE_BGRA_SUPPORT
#ifdef _DEBUG
    | D3D10_CREATE_DEVICE_DEBUG
#endif
    ;

int main () {
    try {
        ID3D10DevicePtr d3ddev;
#ifdef WARP_DEVICE_WORK_AROUND
        D3DV(D3D10CreateDevice(nullptr, D3D10_DRIVER_TYPE_REFERENCE, nullptr, createDeviceFlags, D3D10_SDK_VERSION, &d3ddev));
#else
        D3DV(D3D10CreateDevice(nullptr, D3D10_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, D3D10_SDK_VERSION, &d3ddev));
#endif
        
        // create 3D input image
        unsigned int in_dims[] = {16, 16, 4};
        ID3D10Texture3DPtr in_image = CreateD3D10Texture3d(*d3ddev, in_dims[0], in_dims[1], in_dims[2], DXGI_FORMAT_R8_UNORM, D3D10_USAGE_DYNAMIC);
        {
            ScopedTexureMap3d map(*in_image, D3D10_MAP_WRITE_DISCARD);

            for (unsigned int z = 0; z < in_dims[2]; z++) {
                for (unsigned int y = 0; y < in_dims[1]; y++) {
                    memset((unsigned char*)(map().pData) + map().RowPitch*y + map().DepthPitch*z, 128, in_dims[0]);
                }
            }
        }

        // setup slicer
        VolumeSlicer slicer(*d3ddev, 400, 300);

        // execute slicer
        slicer.Update(*d3ddev, in_image);

        // compare output against reference
        const std::string ref_file = "test_data/VolumeSlicerTests.png";
        const std::string out_file = "test_output/VolumeSlicerTests.png";
        D3DX10SaveTextureToFileA(slicer.m_out_tex, D3DX10_IFF_PNG, out_file.c_str());
        ID3D10Texture2DPtr ref_tex = LoadD3D10Texture2d(*d3ddev, ref_file, false, D3D10_USAGE_STAGING);
        CompareTextures(slicer.m_out_tex, ref_tex, 1, "Please compare "+out_file+" to "+ref_file);
    } catch (std::exception & e) {
        std::cerr << "ERROR: " << e.what() << std::endl;
        return -1;
    }

    std::cout << "SUCESS: All tests passed." << std::endl;
    return 0;
}
