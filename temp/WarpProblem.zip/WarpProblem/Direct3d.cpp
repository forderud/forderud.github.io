#include "Direct3d.hpp"

 ID3D10Texture2DPtr CreateD3D10Texture2d (ID3D10Device & d3ddev, unsigned int width, unsigned int height, DXGI_FORMAT format, D3D10_USAGE usage) {
    // configure texture parameters
    D3D10_TEXTURE2D_DESC tex_desc = {};
    tex_desc.Width            = width;
    tex_desc.Height           = height;
    tex_desc.MipLevels        = 1;
    tex_desc.ArraySize        = 1;
    tex_desc.Format           = format;
    tex_desc.SampleDesc.Count = 1;
    tex_desc.Usage            = usage;
    tex_desc.MiscFlags        = 0;

    if        (usage == D3D10_USAGE_STAGING) {
        tex_desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE | D3D10_CPU_ACCESS_READ;
        tex_desc.BindFlags      = 0;
    } else if (usage == D3D10_USAGE_DYNAMIC) {
        tex_desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
        tex_desc.BindFlags      = D3D10_BIND_SHADER_RESOURCE;
    } else {
        tex_desc.CPUAccessFlags = 0;
        tex_desc.BindFlags      = D3D10_BIND_RENDER_TARGET | D3D10_BIND_SHADER_RESOURCE;
    }

    // create texture.
    ID3D10Texture2DPtr texture;
    D3DV(d3ddev.CreateTexture2D(&tex_desc, nullptr, &texture));

    return texture;
}


 ID3D10Texture3DPtr CreateD3D10Texture3d (ID3D10Device & d3ddev, unsigned int width, unsigned int height, unsigned int depth, DXGI_FORMAT format, D3D10_USAGE usage) {
    // configure texture parameters
    D3D10_TEXTURE3D_DESC tex_desc = {};
    tex_desc.Width            = width;
    tex_desc.Height           = height;
    tex_desc.Depth            = depth;
    tex_desc.MipLevels        = 1;
    tex_desc.Format           = format;
    tex_desc.Usage            = usage;
    tex_desc.MiscFlags        = 0;

    if        (usage == D3D10_USAGE_STAGING) {
        tex_desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE | D3D10_CPU_ACCESS_READ;
        tex_desc.BindFlags      = 0;
    } else if (usage == D3D10_USAGE_DYNAMIC) {
        tex_desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
        tex_desc.BindFlags      = D3D10_BIND_SHADER_RESOURCE;
    } else {
        tex_desc.CPUAccessFlags = 0;
        tex_desc.BindFlags      = D3D10_BIND_RENDER_TARGET | D3D10_BIND_SHADER_RESOURCE;
    }

    // create texture.
    ID3D10Texture3DPtr texture;
    D3DV(d3ddev.CreateTexture3D(&tex_desc, nullptr, &texture));

    return texture;
}


 ID3D10Texture2DPtr LoadD3D10Texture2d (ID3D10Device & d3ddev, const std::string & filename, bool grayscale, D3D10_USAGE usage /*= D3D10_USAGE_DEFAULT*/) {
    // determine format
    DXGI_FORMAT format = DXGI_FORMAT_R8G8B8A8_UNORM;
    if (grayscale)
        format = DXGI_FORMAT_R8_UNORM;

    D3DX10_IMAGE_INFO img_info = {};
    D3DV(D3DX10GetImageInfoFromFileA(filename.c_str(), nullptr, &img_info, nullptr));

    D3DX10_IMAGE_LOAD_INFO load_info;
    load_info.Width     = img_info.Width;
    load_info.Height    = img_info.Height;
    load_info.Format    = format;
    load_info.MipLevels = 1;
    load_info.Usage     = usage;

    if        (usage == D3D10_USAGE_STAGING) {
        load_info.CpuAccessFlags = D3D10_CPU_ACCESS_WRITE | D3D10_CPU_ACCESS_READ;
        load_info.BindFlags      = 0;
    } else if (usage == D3D10_USAGE_DYNAMIC) {
        load_info.CpuAccessFlags = D3D10_CPU_ACCESS_WRITE;
        load_info.BindFlags      = D3D10_BIND_SHADER_RESOURCE;
    } else {
        load_info.BindFlags = D3D10_BIND_RENDER_TARGET | D3D10_BIND_SHADER_RESOURCE;
    }

    // load texture from file
    ID3D10ResourcePtr tmp_res;
    D3DV(D3DX10CreateTextureFromFileA(&d3ddev, filename.c_str(), &load_info, nullptr, &tmp_res, nullptr));
    // cast to more specific texture type
    ID3D10Texture2DPtr color_tex = tmp_res;

    return color_tex;
}
