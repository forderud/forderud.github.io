#pragma once
#include <vector>
#include "Direct3d.hpp"


/** Base-class for textured quadrilaterals with HLSL pixel shaders. */
class HLSLBase {
public:
    /** quadrilateral vertex data-structure */
    struct VERT_TYPE {
        float  x, y, z; ///< screen coordinate
        float  u, v, w; ///< texture coord (spatial coordinate)
    };

    HLSLBase (ID3D10Device & d3ddev, const std::string filename);

    virtual ~HLSLBase ();

    virtual void Render (ID3D10Device & d3ddev, const std::string & techique_name, unsigned int width, unsigned int height);

    ID3D10EffectPtr           m_effect;

protected:
    VERT_TYPE                 m_vertices[4];
    ID3D10InputLayoutPtr      m_vertexLayout;
    ID3D10BufferPtr           m_vertexBuffer;
    ID3D10RasterizerStatePtr  m_rState;
};
