#include "Direct3d.hpp"
#include "TextureAccess.hpp"

#include "TestCommon.hpp"


size_t CountTextureDifferences (ID3D10Texture2D & tex1, ID3D10Texture2D & tex2, int tolerance) {
    // verify that texture types do match
    D3D10_TEXTURE2D_DESC desc1, desc2;
    tex1.GetDesc(&desc1);
    tex2.GetDesc(&desc2);
    if (desc1.Width != desc2.Width)
        throw std::logic_error("inconsistent texture width");
    if (desc1.Height != desc2.Height)
        throw std::logic_error("inconsistent texture height");
    if ( (desc1.Format != DXGI_FORMAT_R8G8B8A8_UNORM) || (desc2.Format != DXGI_FORMAT_R8G8B8A8_UNORM))
        throw std::runtime_error("unsupported image format");

    ScopedTexureMap2d map1(tex1, D3D10_MAP_READ);
    ScopedTexureMap2d map2(tex2, D3D10_MAP_READ);

    size_t diff_counter = 0;

    for (size_t j = 0; j < desc1.Height; j++) {
        const unsigned char * row1 = static_cast<unsigned char *>(map1().pData) + j*map1().RowPitch;
        const unsigned char * row2 = static_cast<unsigned char *>(map2().pData) + j*map2().RowPitch;

        // increment by number of bytes in current pixel format
        for (size_t i = 0; i < 4*desc1.Width; i += 4) {
            const unsigned char * pix1 = row1 + i;
            const unsigned char * pix2 = row2 + i;

            for (size_t c = 0; c < 4; c++) {
                if (abs(pix1[c] - pix2[c]) > tolerance)
                    diff_counter++;
            }
        }
    }

    return diff_counter;
}
