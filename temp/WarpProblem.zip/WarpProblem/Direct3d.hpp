#pragma once
/** Common header file for Direct3D includes */

// link to Direct3D (release libraries)
#pragma comment (lib, "d3d10.lib")
#pragma comment (lib, "d3dx10.lib")
#pragma comment (lib, "DXErr.lib")

#include <string>
#include <vector>
#include <sstream>
#include <functional>
#include <map>
#include <comdef.h>  // COM smart-ptr with "Ptr" suffix

#include <DXErr.h>
#include <d3d10_1.h>
#include <D3DX10math.h>
#include <D3D10effect.h>


// Smart pointers for some Direct3D interfaces.
_COM_SMARTPTR_TYPEDEF(ID3D10Device,            __uuidof(ID3D10Device));
_COM_SMARTPTR_TYPEDEF(ID3D10RenderTargetView,  __uuidof(ID3D10RenderTargetView));
_COM_SMARTPTR_TYPEDEF(ID3D10DepthStencilView,  __uuidof(ID3D10DepthStencilView));

_COM_SMARTPTR_TYPEDEF(ID3D10Buffer,            __uuidof(ID3D10Buffer));
_COM_SMARTPTR_TYPEDEF(ID3D10Resource,          __uuidof(ID3D10Resource));
_COM_SMARTPTR_TYPEDEF(ID3D10Texture2D,         __uuidof(ID3D10Texture2D));
_COM_SMARTPTR_TYPEDEF(ID3D10Texture3D,         __uuidof(ID3D10Texture3D));

_COM_SMARTPTR_TYPEDEF(ID3D10Blob,              __uuidof(ID3D10Blob));
_COM_SMARTPTR_TYPEDEF(ID3D10Effect,                     IID_ID3D10Effect);
_COM_SMARTPTR_TYPEDEF(ID3D10InputLayout,       __uuidof(ID3D10InputLayout));
_COM_SMARTPTR_TYPEDEF(ID3D10RasterizerState,   __uuidof(ID3D10RasterizerState));
_COM_SMARTPTR_TYPEDEF(ID3D10ShaderResourceView,__uuidof(ID3D10ShaderResourceView));



/* COM/Direct3D error handling function */
static void D3DV (HRESULT hr) {
    if (hr == S_OK)
        return;

    const char * err_str  = DXGetErrorStringA(hr);
    const char * err_desc = DXGetErrorDescriptionA(hr);

    std::string message = "D3D error (" + std::string(err_str) + "): " + std::string(err_desc);
    throw std::runtime_error(message);
}

/** Create a new 2D texture. */
ID3D10Texture2DPtr CreateD3D10Texture2d (ID3D10Device & d3ddev, unsigned int width, unsigned int height, DXGI_FORMAT format, D3D10_USAGE usage);

/** Load a image file into a new 2D texture. */
ID3D10Texture2DPtr LoadD3D10Texture2d   (ID3D10Device & d3ddev, const std::string & filename, bool grayscale, D3D10_USAGE usage = D3D10_USAGE_DEFAULT);

/** Create a new 3D texture. */
ID3D10Texture3DPtr CreateD3D10Texture3d (ID3D10Device & d3ddev, unsigned int width, unsigned int height, unsigned int depth, DXGI_FORMAT format, D3D10_USAGE usage);
