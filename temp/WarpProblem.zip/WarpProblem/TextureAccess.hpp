#pragma once
#include <assert.h>
#include "Direct3d.hpp"


/** RAII class for simple mapping of Direct3D textures.
    Textures are automatically unmapped on destruction. */
class ScopedTexureMap2d {
public:
    /** Map a texture for CPU access.
        \param tex  - Direct3D texture pointer (1D, 2D, or 3D)
        \param mode - mapping mode (read/write etc.) */
    ScopedTexureMap2d (ID3D10Texture2D & tex, D3D10_MAP mode) {
        ID3D10DevicePtr d3ddev;
        tex.GetDevice(&d3ddev);

        D3D10_TEXTURE2D_DESC desc = {};
        tex.GetDesc(&desc);

        if (mode == D3D10_MAP_READ) {
            // copy to staging texture that is CPU-readable
            m_staging = CreateD3D10Texture2d(*d3ddev, desc.Width, desc.Height, desc.Format, D3D10_USAGE_STAGING);
            d3ddev->CopyResource(m_staging, &tex);
            D3DV(m_staging->Map(0, mode, 0, &m_map));
        } else  {
            throw std::runtime_error("unsupported texture map mode");
        }
    }

    /** Automatically unmap texture. */
    ~ScopedTexureMap2d () {
        if (m_staging)
            m_staging->Unmap(0);
    }

    /** Access the texture mapping struct. */
    const D3D10_MAPPED_TEXTURE2D & operator () () const {
        return m_map;
    }

private:
    ID3D10Texture2DPtr     m_staging;
    D3D10_MAPPED_TEXTURE2D m_map;
};


/** RAII class for simple mapping of Direct3D textures.
    Textures are automatically unmapped on destruction. */
class ScopedTexureMap3d {
public:
    /** Map a texture for CPU access.
        \param tex  - Direct3D texture pointer (1D, 2D, or 3D)
        \param mode - mapping mode (read/write etc.) */
    ScopedTexureMap3d (ID3D10Texture3D & tex, D3D10_MAP mode) : m_tex(&tex) {
        ID3D10DevicePtr d3ddev;
        tex.GetDevice(&d3ddev);

        D3D10_TEXTURE3D_DESC desc = {};
        tex.GetDesc(&desc);

        if ( (desc.Usage == D3D10_USAGE_DYNAMIC) && (mode == D3D10_MAP_WRITE_DISCARD) ) {
            // can map staging textures directly
            D3DV(m_tex->Map(0, mode, 0, &m_map));
            return;
        } else {
            throw std::runtime_error("unsupported texture map mode");
        }
    }

    /** Automatically unmap texture. */
    ~ScopedTexureMap3d () {
        m_tex->Unmap(0);
    }

    /** Access the texture mapping struct. */
    const D3D10_MAPPED_TEXTURE3D & operator () () const {
        return m_map;
    }

private:
    ID3D10Texture3D      * m_tex;
    D3D10_MAPPED_TEXTURE3D m_map;
};
