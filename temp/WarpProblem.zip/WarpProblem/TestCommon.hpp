#pragma once
#include <vector>
#include <string>

#include "Direct3d.hpp"

/** Counts pixel differences between two 2D textures with a given tolerance. */
size_t CountTextureDifferences (ID3D10Texture2D & tex1, ID3D10Texture2D & tex2, int tolerance);


/** Convenience function to compare textures.
    Outputs an error message when comparison fails. */
template <class D3DTexType>
void CompareTextures (D3DTexType & tex1, D3DTexType & tex2, int tolerance, const std::string & error_msg) {
    size_t diff_counter = CountTextureDifferences(tex1, tex2, tolerance);

    if (diff_counter > 0) {
        std::ostringstream os;
        os << "There where " << diff_counter << " differences.\n" << error_msg;
        throw std::runtime_error(os.str());
    }
}
