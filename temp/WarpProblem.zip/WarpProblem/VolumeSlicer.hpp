#pragma once
#include <memory>  // shared_ptr
#include "HLSLBase.hpp"


class VolumeSlicer {
public:
    VolumeSlicer (ID3D10Device & d3ddev, unsigned int width, unsigned int height) : m_quad(d3ddev, "VolumeSlicer.fx") {
        // configure output texture
        m_out_tex = CreateD3D10Texture2d(d3ddev, width, height, DXGI_FORMAT_R8G8B8A8_UNORM, D3D10_USAGE_DEFAULT);

        // configure color-map
        m_tissue_color = CreateD3D10Texture2d(d3ddev, 256, 1, DXGI_FORMAT_R8G8B8A8_UNORM, D3D10_USAGE_DEFAULT);
        ID3D10RenderTargetViewPtr ren_target;
        D3DV(d3ddev.CreateRenderTargetView(m_tissue_color,   nullptr, &ren_target));
        float clear_color[] = {0.5f, 0.5f, 0.5f, 1.0f}; // RGBA
        d3ddev.ClearRenderTargetView(ren_target, clear_color);
    }

    virtual ~VolumeSlicer () {
    }

    virtual void Update (ID3D10Device & d3ddev, ID3D10Texture3D & input) {
        // render to color + depth buffers from texture
        ID3D10RenderTargetViewPtr tex_target;
        D3DV(d3ddev.CreateRenderTargetView(m_out_tex, nullptr, &tex_target));

        // configure shader
        float thickness[] = {0, 0, 0.0001f, 0};
        D3DV(m_quad.m_effect->GetVariableByName("Thickness")->AsVector()->SetFloatVector(thickness));
        D3DV(m_quad.m_effect->GetVariableByName("SliceCount")->AsScalar()->SetInt(3));
 
        ID3D10ShaderResourceViewPtr input_tex;
        D3DV(d3ddev.CreateShaderResourceView(&input, nullptr, &input_tex));
        D3DV(m_quad.m_effect->GetVariableByName("ImageTexture")->AsShaderResource()->SetResource(input_tex));

        ID3D10ShaderResourceViewPtr tissue_color;
        D3DV(d3ddev.CreateShaderResourceView(m_tissue_color, nullptr, &tissue_color));
        D3DV(m_quad.m_effect->GetVariableByName("TissueColorTexture")->AsShaderResource()->SetResource(tissue_color));

        {
            ID3D10RenderTargetView * cur_targets[] = {tex_target};
            d3ddev.OMSetRenderTargets(1, cur_targets, nullptr);
        }

        // execute shader
        D3D10_TEXTURE2D_DESC desc = {};      
        m_out_tex->GetDesc(&desc);
        m_quad.Render(d3ddev, "PolarTissueThickMax", desc.Width, desc.Height);

        // clear non-owned texture bindings
        D3DV(m_quad.m_effect->GetVariableByName("ImageTexture")->AsShaderResource()->SetResource(nullptr));
    }

    ID3D10Texture2DPtr m_out_tex;      ///< internally generated output texture

private:
    ID3D10Texture2DPtr m_tissue_color;
    HLSLBase           m_quad;
};
